//question 1
var output = isOldEnoughToDrink(22);
console.log(output); // --> true


function isOldEnoughToDrink(age){

    if (age >= 18)
    return true;
        
   


}

//question 2

var output = isOldEnoughToDrinkAndDrive(22);
console.log(output); // --> false
 

function isOldEnoughToDrinkAndDrive(age){

    if (age >= 21 ){
    
        console.log("can drink")
        if (true){
            return false;
        }
    }

    

}


//question 3
var obj = {
    key: 'value'
  };
  var output = getProperty(obj, 'key');
  console.log(output); // --> 'value'

  function getProperty(obj,key){
           
          return obj.key;

     
  }

  //question 4 
  var myObj = {};
addProperty(myObj, 'myProperty');
console.log(myObj.myProperty); // --> true


  function addProperty(myObj,myProperty){
      return myObj.myProperty =true
  }
 



//question 5

var obj = {
    age: 45
  };
  var output = isPersonOldEnoughToDrinkAndDrive(obj);
  console.log(output); // --> false



function isPersonOldEnoughToDrinkAndDrive(obj){
      if (obj.age >= 18){
        return true
      }
      
 else{
    return false

 } 


}

//question 6 
var output = computeAverageLengthOfWords('code', 'programs');

console.log(output); // --> 6
function    computeAverageLengthOfWords(code, programs){
        let code1 = code.length
        let code2 = programs.length
             
       return  avarage = (code1 + code2) / 2 
        
}


//question 7 

  function transformFirstAndLast(...item){
      
          return item.pop
      
          }

console.log(transformFirstAndLast(["kevin","dami","anita", "james"]))


//question 8
var input = {
    name : 'Sam',
    age : 25,
    hasPets : true
  };
  
function getAllKeys(input){
    for(let value of input){
        return input.value
    }


}
